from django.urls import path
from . import views
from . import forms
from django.contrib import admin 


app_name = 'home'  # here for namespacing of urls.


urlpatterns = [ 
	path('admin/', admin.site.urls), 
	path('postsignIn/upload/',views.upload, name='upload'),
	path('', views.signIn),
	path('postsignIn/', views.postsignIn), 
	path('signUp/', views.signUp, name='signup'), 
	path('logout/', views.logout, name='log'), 
	path('postsignUp/', views.postsignUp), 
	path('dashboard/',views.dashboard,name="dashboard")
] 