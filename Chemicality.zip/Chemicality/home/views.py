from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib import messages, admin
import xlrd
import csv
from requests import request
from home.forms import DocumentForm
import pandas as pd
from sklearn import svm, preprocessing
import matplotlib.pyplot as plt
import datetime
import json
from google_trans_new import google_translator
from pyrebase import pyrebase
import tabula
# Create your views here.

def home(request): 
	return render(request,"home\Home.html") 

def home(request):
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('Dashboard')
    else:
        form = DocumentForm()
    return render(request, 'home\Home.html', {
        'form': form
    })

def dashboard(request):
	import tabula
	translator = google_translator()
	pdf_path = "https://h20195.www2.hp.com/v2/GetDocument.aspx?docname=c04932490"
	data_xls_output=tabula.convert_into(pdf_path,"chemicaloutput.csv",output_format="csv", pages='15-20')
	data_xls_input = pd.read_excel('C:\\Users\\chris\\Downloads\\Chemicality\\documents\\chemicalinput.xlsx')
	data_xls_input.to_csv('chemicalsinput.csv',index=False)
	outputdf=pd.read_csv('chemicalsoutput.csv')
	inputdf=pd.read_csv('chemicalsinput.csv')
	for i in range(13):
		inputdf['対　　象　　物　　質　　名'][i]=translator.translate(inputdf['対　　象　　物　　質　　名'][i])
	inputlist=list(inputdf['対　　象　　物　　質　　名'])
	inputdf['閾値（法規制値）.1'][i]=translator.translate(inputdf['閾値（法規制値）.1'][i])
	inputlistThreshold=list(inputdf['閾値（法規制値）.1'])
	outputlist=list(outputdf['Substances and materials'])
	outputlistThreshold=list(outputdf['Threshold limit'])
	for ele in outputlist:
		if ele in inputlist:
			foundSomething="We were able to find",ele
		else:
			notFound="We weren't able to find any matching chemicals. Try again?"
			self.message_user(request, ele, level=messages.ERROR)
	searchedChemical = 'Lead'
	for j in outputlist:
		if searchedChemical==j:
			searchFound='Yes, we use', searchedChemical
		else:
			for x in j:
				if searchedChemical in x:
					searchSuggestions="No, that doesn't exist here. Did you mean", x,"? We have that."
				else:
					searchNotFound="We're sorry, we couldn't find any results"
	displayChemicals = pd.DataFrame(inputlist, columns=['What you inputted'])
	displayChemicals['What we have']=pd.DataFrame(outputlist)
	displayChemicals['Threshold limit of your compounds']=pd.DataFrame(inputlistThreshold)
	displayChemicals['Threshold limit of our compounds']=pd.DataFrame(outputlistThreshold)
	displayChemicalsUrInput=list(displayChemicals['What you inputted'])
	displayChemicalsOurOutput=list(displayChemicals['What we have'])
	displayChemicalsUrThreshold=list(displayChemicals['Threshold limit of your compounds'])
	displayChemicalsOurThreshold=list(displayChemicals['Threshold limit of our compounds'])
	return render(request, "home\dashboard.html", {
		'notFound':notFound,
		'searchNotFound':searchNotFound,
		'displayChemicalsUrInput':displayChemicalsUrInput,
		'displayChemicalsUrOutput':displayChemicalsOurOutput,
		'displayChemicalsUrThreshold':displayChemicalsUrThreshold,
		'displayChemicalOurThreshold':displayChemicalsOurThreshold})