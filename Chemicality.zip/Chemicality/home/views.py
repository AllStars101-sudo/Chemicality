from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib import messages, admin
import xlrd
import csv
from requests import request
from home.forms import DocumentForm
import pandas as pd
from sklearn import svm, preprocessing
import matplotlib.pyplot as plt
import datetime
import json
from google_trans_new import google_translator
from pyrebase import pyrebase
import tabula
# Create your views here.

config={ 
	"apiKey": "AIzaSyBnce0CWYf24zV53BY9v98nI6_5U8lSIRA", 
	"authDomain": "fir-login-b1ebf.firebaseapp.com", 
	"databaseURL": "https://fir-login-b1ebf.firebaseio.com", 
	"projectId": "fir-login-b1ebf", 
	"storageBucket": "fir-login-b1ebf.appspot.com", 
	"messagingSenderId": "294438307046", 
	"appId": "1:294438307046:web:91d7d85c9f7679e909e727"
} 
# Initialising database,auth and firebase for further use 
firebase=pyrebase.initialize_app(config) 
authe = firebase.auth() 
database=firebase.database() 

def signIn(request): 
	return render(request,"home\Login.html") 


def home(request): 
	return render(request, 'home\Home.html')

def postsignIn(request): 
	email=request.POST.get('email') 
	pasw=request.POST.get('pass') 
	try: 
		# if there is no error then signin the user with given email and password 
		user=authe.sign_in_with_email_and_password(email,pasw)
		return HttpResponseRedirect('upload')
	except: 
		message="Wrong credentials. Please try again."
		return render(request,"home\Login.html",{"message":message}) 
	session_id=user['idToken'] 
	request.session['uid']=str(session_id) 


def logout(request): 
	try: 
		del request.session['uid'] 
	except: 
		pass
	return render(request,"home\Login.html") 

def signUp(request): 
	return render(request,"home\Registration.html") 

def postsignUp(request): 
	email = request.POST.get('email') 
	passs = request.POST.get('pass') 
	name = request.POST.get('name') 
	try: 
		# creating a user with the given email and password 
		user=authe.create_user_with_email_and_password(email,passs) 
		uid = user['localId'] 
		idtoken = request.session['uid'] 
		print(uid) 
	except: 
		return render(request, "home\Registration.html") 
	return render(request,"home\Home.html")

#end


def homepage(request):
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('dashboard')
    else:
        form = DocumentForm()
    return render(request, 'home\Home.html', {
        'form': form
    })


def upload(request):
	if request.method == 'POST':
		form = DocumentForm(request.POST, request.FILES)
		if form.is_valid():
			form.save()
			return HttpResponseRedirect('dashboard')
	else:
		form = DocumentForm()
	return render(request, r'home\upload.html', {
        'form': form,
	})


def dashboard(request):
	import tabula
	translator = google_translator()
	pdf_path = "https://h20195.www2.hp.com/v2/GetDocument.aspx?docname=c04932490"
	data_xls_output=tabula.convert_into(pdf_path,"chemicaloutput.csv",output_format="csv", pages='15-20')
	data_xls_input = pd.read_excel('C:\\Users\\chris\\Downloads\\Chemicality\\documents\\chemicalinput.xlsx')
	data_xls_input.to_csv('chemicalsinput.csv',index=False)
	outputdf=pd.read_csv('chemicalsoutput.csv')
	inputdf=pd.read_csv('chemicalsinput.csv')
	for i in range(13):
		inputdf['対　　象　　物　　質　　名'][i]=translator.translate(inputdf['対　　象　　物　　質　　名'][i])
	inputlist=list(inputdf['対　　象　　物　　質　　名'])
	inputdf['閾値（法規制値）.1'][i]=translator.translate(inputdf['閾値（法規制値）.1'][i])
	inputlistThreshold=list(inputdf['閾値（法規制値）.1'])
	outputlist=list(outputdf['Substances and materials'])
	outputlistThreshold=list(outputdf['Threshold limit'])
	for ele in outputlist:
		if ele in inputlist:
			foundSomething="We were able to find",ele
		else:
			notFound="We weren't able to find any matching chemicals. Try again?"
			self.message_user(request, ele, level=messages.ERROR)
	searchedChemical = 'Lead'
	for j in outputlist:
		if searchedChemical==j:
			searchFound='Yes, we use', searchedChemical
		else:
			for x in j:
				if searchedChemical in x:
					searchSuggestions="No, that doesn't exist here. Did you mean", x,"? We have that."
				else:
					searchNotFound="We're sorry, we couldn't find any results"
	displayChemicals = pd.DataFrame(inputlist, columns=['What you inputted'])
	displayChemicals['What we have']=pd.DataFrame(outputlist)
	displayChemicals['Threshold limit of your compounds']=pd.DataFrame(inputlistThreshold)
	displayChemicals['Threshold limit of our compounds']=pd.DataFrame(outputlistThreshold)
	displayChemicalsUrInput=list(displayChemicals['What you inputted'])
	displayChemicalsOurOutput=list(displayChemicals['What we have'])
	displayChemicalsUrThreshold=list(displayChemicals['Threshold limit of your compounds'])
	displayChemicalsOurThreshold=list(displayChemicals['Threshold limit of our compounds'])
	return render(request, 'home\dashboard.html', {
        'foundSomething':foundSomething,
		'notFound':notFound,
		'searchFound':searchFound,
		'searchNotFound':searchNotFound,
		'displayChemicalsUrInput':displayChemicalsUrInput,
		'displayChemicalsUrOutput':displayChemicalsOurOutput,
		'displayChemicalsUrThreshold':displayChemicalsUrThreshold,
		'displayChemicalOurThreshold':displayChemicalsOurThreshold,
    })